package com.huwei.dev.util;

import org.junit.Test;

public class patternTest {

    private static String pattern = ".*(/v1/common/login).*";

    @Test
    public void regex(){
        System.out.println("http://localhost:8088/myapp/v1/common/login?userName=admin&passWord=admin".matches(pattern));
    }

}
