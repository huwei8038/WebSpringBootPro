package com.huwei.dev.util;

import com.huwei.dev.RunApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = RunApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class JwtUtilTest {

    @Test
  public void getToken() {
        System.out.println(JwtUtil.getToken(0,"121"));
    }

    @Test
    public void verify() {
        System.out.println(JwtUtil.verify("eyJhbGciOiJIUzI1NiIsIlR5cGUiOiJKd3QiLCJ0eXAiOiJKV1QifQ.eyJleHAiOjE2MDY1NTU4ODksInVzZXJJZCI6IjEyMSIsImlhdCI6MTYwNjU1NTgyOX0.Cp87dn7ynLrQJcPcD8YJ6ms9X6bni_ecUraTwEQFpvk"));
    }

    @Test
    public void getTokenMessage() {
    }
}