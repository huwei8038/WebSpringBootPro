package com.huwei.dev.util;

import com.huwei.dev.entity.ContextEntity;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

/**
 * @author huwei
 */
public class HtmlParseUtil {

    public static void main(String[] args) throws IOException {
        String keyword = "定时";
        ArrayList<ContextEntity> arrayList = htmlParseContext(keyword);
        System.out.println(arrayList.toString());

    }
    
    /**
     * htmlParseContext
     *
     * @throws IOException
     */
    private static ArrayList<ContextEntity> htmlParseContext(String keyword) throws IOException {
        String url = "https://search.jd.com/Search?keyword="+keyword;
        Document parse = Jsoup.parse(new URL(url),30000);
        Element element = parse.getElementById("J_goodsList");
        Elements elements = element.getElementsByTag("li");
        ArrayList<ContextEntity> arrayList = new ArrayList<ContextEntity>();
        for (Element e : elements) {
            String img = e.getElementsByTag("img").eq(0).attr("data-lazy-img");
            String price = e.getElementsByClass("p-price").eq(0).text();
            String title = e.getElementsByClass("p-name").eq(0).text();
            String press = e.getElementsByClass("p-shopnum").eq(0).text();
            arrayList.add(new ContextEntity(title,price,img,press));
        }
        return arrayList;
    }

}
