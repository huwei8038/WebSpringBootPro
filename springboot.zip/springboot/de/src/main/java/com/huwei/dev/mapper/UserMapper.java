package com.huwei.dev.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * @author huwei
 */
@Mapper
@Component
public interface UserMapper {
    Integer selectByUserEntity(@Param("userName") String userName,@Param("passWord") String passWord);
}
