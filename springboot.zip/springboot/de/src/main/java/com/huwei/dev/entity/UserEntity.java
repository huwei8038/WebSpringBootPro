package com.huwei.dev.entity;

/**
 * @author huwei
 */

public class UserEntity {
    private String userName;

    private String passWord;

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public UserEntity(String userName, String passWord) {
        this.userName = userName;
        this.passWord = passWord;
    }

    public UserEntity() {}

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return "UserEntity{" +
                "userName='" + userName + '\'' +
                ", passWord='" + passWord + '\'' +
                '}';
    }
}
