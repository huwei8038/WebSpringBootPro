package com.huwei.dev.controller;

import com.huwei.dev.entity.vo.ResultVO;
import com.huwei.dev.entity.vo.UserEntityVO;
import com.huwei.dev.service.impl.LoginServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author huwei
 */
@RestController
@RequestMapping("/v1/common")
public class LoginController {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private LoginServiceImpl loginService;

    @PostMapping("/login")
    public ResultVO login(@RequestBody UserEntityVO userEntityVO) {
        LOGGER.info("LoginController.login param is {}", userEntityVO);
        ResultVO result = loginService.login(userEntityVO);
        return result;
    }

}
