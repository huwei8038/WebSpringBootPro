package com.huwei.dev.exception;

import com.huwei.dev.entity.vo.ResultVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author huwei
 */
@ControllerAdvice
public class GlobalException {
    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalException.class);

    private static ResultVO resultVO = new ResultVO();

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ResultVO ExceptionHandler(Exception e){
        LOGGER.error("redis 连接异常:{}",e.getMessage());
        resultVO.setStatusCode(500);
        resultVO.setData(null);
        resultVO.setResultMessage("异常");
        return resultVO;
    }
}
