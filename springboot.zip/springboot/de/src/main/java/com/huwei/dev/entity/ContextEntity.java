package com.huwei.dev.entity;

/**
 * @author huwei
 */
public class ContextEntity {

    private String title;
    private String price;
    private String img;
    private String press;

    public ContextEntity() {
    }

    public String getPress() {
        return press;
    }

    public void setPress(String press) {
        this.press = press;
    }

    public ContextEntity(String title, String price, String img, String press) {
        this.title = title;
        this.price = price;
        this.img = img;
        this.press = press;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    @Override
    public String toString() {
        return "ContextEntity{" +
                "title='" + title + '\'' +
                ", price='" + price + '\'' +
                ", img='" + img + '\'' +
                ", press='" + press + '\'' +
                '}';
    }
}
