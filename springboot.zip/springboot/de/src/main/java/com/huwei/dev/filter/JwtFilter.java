package com.huwei.dev.filter;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.huwei.dev.entity.vo.ResultVO;
import com.huwei.dev.util.JsonUtil;
import com.huwei.dev.util.JwtUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author huwei
 */
public class JwtFilter implements Filter {

    private static final Logger LOGGER = LoggerFactory.getLogger(JwtFilter.class);

    private static String pattern = ".*(/v1/common/login).*";

    @Override
    public void init(FilterConfig filterConfig) {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException {
        HttpServletRequest req = (HttpServletRequest)request;
        HttpServletResponse rep = (HttpServletResponse)response;
        try {
            // 无需登录
            if(req.getRequestURI().matches(pattern)){
                chain.doFilter(request, response);
                return;
            }
            String userAgent = req.getHeader("UserAgent");
            if(StringUtils.isNotEmpty(userAgent)) {
                DecodedJWT jwt = JwtUtil.verify(userAgent);
                // 认证信息过期判断
                if(jwt != null){
                    chain.doFilter(request, response);
                }
            }
            // 无认证信息，请先去登录
            ResultVO resultVO = new ResultVO();
            resultVO.setStatusCode(401);
            resultVO.setResultMessage("未登录");
            rep.setCharacterEncoding("UTF-8");
            rep.getWriter().write(JsonUtil.toJSONString(resultVO));
            rep.getWriter().flush();
            return;
        } catch (IOException | ServletException e) {
            LOGGER.error("SSOFilter is exception :{}" ,e.getMessage());
        }
    }

    @Override
    public void destroy() {
    }
}
