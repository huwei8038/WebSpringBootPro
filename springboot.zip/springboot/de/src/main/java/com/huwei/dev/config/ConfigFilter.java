package com.huwei.dev.config;

import com.huwei.dev.filter.JwtFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author huwei
 */
@Configuration
public class ConfigFilter {

   @Bean
    public FilterRegistrationBean filterRegistrationBean() {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(new JwtFilter());
        filterRegistrationBean.setOrder(1);
        filterRegistrationBean.addUrlPatterns(new String[] { "/*" });
        return filterRegistrationBean;
    }

}
