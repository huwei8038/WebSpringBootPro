package com.huwei.dev.entity.vo;

/**
 * @author huwei
 */
public class ResultVO {
    private int statusCode;

    private String resultMessage;

    private Object data;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public ResultVO() {
    }

    public ResultVO(int statusCode, String resultMessage, Class data) {
        this.statusCode = statusCode;
        this.resultMessage = resultMessage;
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResultVO{" +
                "statusCode=" + statusCode +
                ", resultMessage='" + resultMessage + '\'' +
                ", data=" + data +
                '}';
    }
}
