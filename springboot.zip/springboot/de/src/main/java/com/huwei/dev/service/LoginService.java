package com.huwei.dev.service;

import com.huwei.dev.entity.vo.ResultVO;
import com.huwei.dev.entity.vo.UserEntityVO;

/**
 * @author huwei
 */
public interface LoginService {
    /**
     * login
     *
     * @param userEntityVO UserEntityVO
     * @return ResultVO
     */
   public ResultVO login(UserEntityVO userEntityVO);
}
