package com.huwei.dev.entity.vo;


import com.huwei.dev.entity.UserEntity;

/**
 * @author huwei
 */
public class UserEntityVO extends UserEntity {

}
