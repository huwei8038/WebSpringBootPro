package com.huwei.dev.service.impl;

import com.huwei.dev.entity.vo.ResultVO;
import com.huwei.dev.entity.vo.UserEntityVO;
import com.huwei.dev.mapper.UserMapper;
import com.huwei.dev.service.LoginService;
import com.huwei.dev.util.JwtUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author huwei
 */
@Service
@Transactional
public class LoginServiceImpl implements LoginService {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginServiceImpl.class);

    @Autowired
    private UserMapper userMapper;

    @Autowired
    @Qualifier("redisTemplate")
    private RedisTemplate redisTemplate;

    @Override
    public ResultVO login(UserEntityVO userEntityVO) {
        ResultVO resultVO = new ResultVO();
        try {
            if (userEntityVO == null || StringUtils.isEmpty(userEntityVO.getUserName()) || StringUtils.isEmpty(userEntityVO.getPassWord())) {
                resultVO.setStatusCode(500);
                resultVO.setResultMessage("登录失败，请检查参数");
                return resultVO;
            }
            Integer userId = userMapper.selectByUserEntity(userEntityVO.getUserName(), userEntityVO.getPassWord());
            if (userId != null) {
                String token = JwtUtil.getToken(0, String.valueOf(userId));
                redisTemplate.opsForValue().set("token",token);
                redisTemplate.opsForValue().set("user",userEntityVO);
                resultVO.setStatusCode(200);
                resultVO.setResultMessage("登录成功");
                resultVO.setData(token);
                return resultVO;
            }
            resultVO.setStatusCode(400);
            resultVO.setResultMessage("未注册");
            return resultVO;
        } catch (Exception e) {
            LOGGER.error("login is exception : {} ", e);
            return null;
        }
    }


}
