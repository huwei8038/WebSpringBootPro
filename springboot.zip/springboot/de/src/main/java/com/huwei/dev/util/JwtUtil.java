package com.huwei.dev.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author huwei
 */
public class JwtUtil {

    private static String TOKEN_SECRET="WFAG3WVSDAGERYTGWERB";

    public static String getToken(long time, String userId) {
        try {
            time = (long) 1000*60;
            Date date = new Date(System.currentTimeMillis() + time);
            Algorithm algorithm = Algorithm.HMAC256(TOKEN_SECRET);
            Map<String, Object> header = new HashMap<>(2);
            header.put("Type", "Jwt");
            header.put("alg", "HS256");
            return JWT.create()
                    .withHeader(header)
                    .withClaim("userId", userId)
                    .withIssuedAt(new Date())
                    .withExpiresAt(date)
                    .sign(algorithm);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static DecodedJWT verify(String token) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(TOKEN_SECRET);
            JWTVerifier verifier = JWT.require(algorithm).build();
            DecodedJWT jwt = verifier.verify(token);
            return jwt;
        } catch (Exception e) {
            return null;
        }
    }

    public static Map<String, Claim> getTokenMessage(DecodedJWT jwt) {
        try {
            Map<String, Claim> message = jwt.getClaims();
            return message;
        } catch (Exception e) {
            return null;
        }
    }
}

